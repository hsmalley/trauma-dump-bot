<!-- @format -->

# 🧠 Cognitive Behavioral Therapy (CBT)

## Definition and Core Themes

**CBT** is a structured therapeutic approach that targets the relationship between **thoughts, emotions, and behaviors**. It helps individuals recognize and reframe distorted thinking patterns to reduce emotional distress and build healthier coping.

Core concepts:

- Our thoughts shape our feelings and actions
- Distorted cognitions can be identified and challenged
- Behavior experiments help reinforce new beliefs
- Skill-building is key to change

---

## Traits and Lived Experience

- Focuses on present-time functioning
- Uses worksheets, thought logs, and behavioral activation
- Often short-term and goal-oriented
- Can be validating for people who benefit from structure and logic

---

## Nervous System and Parts Work Lens

- **Nervous System**: CBT may bypass somatic state if not adapted for trauma
- **Parts**:
  - **Fixer**: “Let’s solve this with logic.”
  - **Avoider**: “If I change my thought, maybe I can skip this feeling.”
  - **Inner Critic**: May weaponize CBT against emotion (“Stop being irrational”)

---

## Attachment and Relational Patterns

- May support interrupting protest behaviors with reframes
- Useful for self-soothing and shifting cognitive distortions in relationships
- May need supplementation for attachment trauma or dysregulation

---

## Misunderstandings and Reframes

❌ _“Just change your thoughts”_  
✅ Change often requires emotional, somatic, and contextual support.

❌ _“It’s just about being rational”_  
✅ CBT includes identifying core beliefs, not ignoring emotion.

❌ _“It’s not useful for trauma”_  
✅ CBT can help with trauma recovery when integrated into a broader, attuned approach.

---

## Relational Challenges and Strengths

**Challenges:**

- May feel invalidating for people in intense emotional states
- Can miss parts-based complexity or systemic context

**Strengths:**

- Clear tools and language for change
- Encourages insight and agency
- Can help unhook from shame-based narratives

---

## Strategies, Prompts, and Practices

- Thought log: “What happened? What did I think? What else might be true?”
- Reframe: “Is this thought helpful? What’s a more compassionate version?”
- Behavior experiment: “What small step could I try to test this belief?”
- Self-compassion prompt: “Would I say this to a friend?”

---

## Related Frameworks and Further Reading

- **ACT (Acceptance and Commitment Therapy)**
- **IFS (Internal Family Systems)**
- **DBT (Dialectical Behavior Therapy)**
- _Mind Over Mood_ by Greenberger & Padesky
