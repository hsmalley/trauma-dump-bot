<!-- @format -->

# 🧠 Compassion-Focused Therapy (CFT)

## Definition and Core Themes

**CFT** is a therapeutic approach designed to help people who struggle with high self-criticism, shame, and emotional dysregulation. It integrates neuroscience, evolutionary theory, and attachment science to cultivate **self-compassion** and **inner safety**.

Core ideas:

- The brain has evolved threat, drive, and soothe systems
- Shame and self-attack activate threat and suppress soothe
- Compassion is a trainable capacity that regulates threat responses
- Compassion ≠ indulgence—it’s fierce, wise, and protective

---

## Traits and Lived Experience

- Common in trauma survivors and marginalized identities
- May involve difficulty receiving care or softness from others
- Can feel foreign or unsafe to offer self-kindness at first
- Supports reparenting, inner ally development, and self-trust

---

## Nervous System and Parts Work Lens

- **Nervous System**: CFT helps shift from sympathetic/dorsal states into ventral safety
- **Parts**:
  - **Self-Critic**: “You’re not enough—you’ll be abandoned.”
  - **Protector**: “Don’t feel that—it’s too dangerous.”
  - **Compassionate Self**: “You didn’t choose this pain, but you get to choose how you meet it.”

---

## Attachment and Relational Patterns

- Builds internal secure attachment through self-to-part relating
- Enhances capacity for co-regulation without collapse or overfunctioning
- Reframes vulnerability as strength

---

## Misunderstandings and Reframes

❌ _“Compassion is weakness”_  
✅ Compassion is active courage—especially toward parts we reject.

❌ _“Self-kindness is indulgent”_  
✅ Kindness builds resilience, not fragility.

❌ _“I have to love myself to be worthy”_  
✅ Worthiness is unconditional—compassion reveals it, not earns it.

---

## Relational Challenges and Strengths

**Challenges:**

- Resistance to softness or kindness from trauma adaptations
- Fear of collapsing or losing motivation
- Critic parts may fight back harder at first

**Strengths:**

- Builds emotional safety and inner trust
- Allows for sustainable healing and connection
- Can transform shame into tenderness and strength

---

## Strategies, Prompts, and Practices

- Soothing rhythm breathing or self-touch
- Dialogue: “What does this hurting part need from Compassionate Self?”
- Reframe: “This pain is not proof of failure—it’s a cue for care.”
- Imagery: Safe place, inner mentor, or compassionate ally

---

## Related Frameworks and Further Reading

- **IFS (Internal Family Systems)**
- **Attachment Theory**
- **Shame Resilience Theory (Brené Brown)**
- _The Compassionate Mind_ by Paul Gilbert
- _Radical Compassion_ by Tara Brach
