<!-- @format -->

# 🧠 Rejection Sensitive Dysphoria (RSD)

## Definition and Core Themes

**Rejection Sensitive Dysphoria (RSD)** refers to the intense emotional pain triggered by perceived or actual rejection, criticism, or disapproval. While not a clinical diagnosis, RSD is often described in ADHD and AuDHD communities as a lived phenomenon marked by sudden, overwhelming distress that can feel disproportionate to the event.

Core themes:

- Heightened threat sensitivity to social disconnection
- Rapid onset emotional overwhelm (grief, shame, anger)
- Defensive or avoidant coping (shutdown, rage, fawn, withdrawal)
- Deep craving for belonging mixed with fear of being “too much” or “not enough”

RSD may show up as a _nervous system hijack_ and is often rooted in early experiences of invalidation, bullying, or identity-based exclusion.

## Traits and Lived Experience

- Feels like emotional “whiplash” after minor perceived rejection
- Preemptively avoids asking for needs or initiating vulnerable conversation
- Over-apologizes or over-explains to secure approval
- Struggles with group dynamics (e.g., being left on read, not invited)
- Easily derailed by neutral or constructive feedback
- May interpret even slight disengagement as a rupture or abandonment

This isn’t about overreacting—it’s about a **highly sensitized threat detection system** shaped by experiences where rejection _was_ dangerous or costly.

## Nervous System and Parts Work Lens

- **Nervous System:** Often drops quickly into _sympathetic mobilization_ (panic, urgency) or _dorsal shutdown_ (numb, checked out). Can oscillate between rage and collapse.
- **Parts:**
  - **Exile**: “If they reject me, it means I’m unlovable.”
  - **Manager**: “I have to be perfect, pleasing, invisible, or productive.”
  - **Firefighter**: “Blow it up before I get hurt.” (rage quit, ghosting, compulsive behaviors)

## Attachment and Relational Patterns

- **Protest behaviors** may include people-pleasing, rapid emotional bids, reassurance-seeking, or hostile withdrawal
- **Attachment fears** center on conditional acceptance—“I’ll only be loved if I perform correctly or never inconvenience others”
- May self-sabotage or pull away to avoid “inevitable” rejection

## Misunderstandings and Reframes

❌ _“They’re just too sensitive”_  
✅ **RSD isn’t about sensitivity—it’s about survival**. The pain is real and somatic.

❌ _“They’re being dramatic or manipulative”_  
✅ RSD responses are often unconscious trauma adaptations, not calculated behaviors.

❌ _“They need to toughen up”_  
✅ Building nervous system regulation, not suppression, supports resilience.

## Relational Challenges and Strengths

**Challenges:**

- Hard to believe others like or care about them
- Assumes criticism means rejection
- Often overfunctions in relationships out of fear of being dropped
- Can miss repair attempts due to hypervigilance

**Strengths:**

- Deep emotional attunement and loyalty
- Highly motivated to maintain connection and avoid harm
- Often quick to self-reflect once nervous system is settled
- Capable of building strong trust when safety is consistent

## Strategies, Prompts, and Practices

**Somatic / Regulation:**

- “Where am I on the ladder?” (Polyvagal check-in)
- Hand-to-heart grounding: “I’m not in danger even if this feels intense”
- Exit scripts: “I need 5 minutes—I’ll be back after a walk or breath reset.”

**IFS-Inspired Prompts:**

- “What does the part of me who fears rejection need to feel safe?”
- “Who in me is trying to protect me from this feeling?”

**Relational Scripts:**

- “My nervous system is loud right now—I may need extra reassurance, but I’m working on it.”
- “Can you tell me how you’re feeling about me? My brain is spinning stories.”

**RSD Repair Practice:**

- Micro-apology + reassurance:  
  “I felt reactive because I got scared—I care about this relationship and I’m calming down now.”

## Related Frameworks and Further Reading

- **Attachment Theory** (especially anxious/preoccupied dynamics)
- **Polyvagal Theory** (threat detection and autonomic shifts)
- **Internal Family Systems (IFS)** (parts holding shame, panic, and protector roles)
- **Shame Resilience Theory** (Brené Brown)
- **AuDHD lived experience writing** (e.g., Devon Price, Neurodivergent Insights)
