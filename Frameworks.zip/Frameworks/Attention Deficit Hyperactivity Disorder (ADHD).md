<!-- @format -->

# 🧠 Attention Deficit Hyperactivity Disorder (ADHD)

## Definition and Core Themes

ADHD is a neurodevelopmental style characterized by dynamic attention regulation, impulsivity, and hyperactivity—though it manifests differently across individuals. Rather than a deficit, ADHD often represents a mismatch between internal rhythms and dominant cultural expectations.

Core insights:

- ADHD is contextual, not just internal
- Interest-based nervous system: attention flows to novelty, urgency, or deep interest
- Time blindness, task initiation difficulty, and emotional reactivity are common
- Shame and rejection sensitivity are frequent companions

---

## Traits and Lived Experience

- Bursts of hyperfocus followed by burnout or paralysis
- Interrupting, forgetfulness, or "inconsistent performance" (not intentional)
- Struggles with transitions, prioritization, and follow-through
- Often deeply creative, intuitive, and attuned to patterns others miss

---

## Nervous System and Parts Work Lens

- **Nervous System**: Sympathetic spikes (urgency, panic) and dorsal dips (shutdown, overwhelm)
- **Parts**:
  - **Inner Critic**: “Why can’t you just do the thing?”
  - **Overfunctioner**: Tries to hide inconsistency by doing too much
  - **Exile**: Carries shame from years of being “too much” or “not enough”

---

## Attachment and Relational Patterns

- Repeated rupture from being misunderstood or misattuned to
- Over-apologizing or masking in relationships
- Sensitivity to rejection or criticism (see: RSD)
- Deep desire for attuned connection, often with difficulty sustaining routines

---

## Misunderstandings and Reframes

❌ _“You’re just lazy or disorganized”_  
✅ ADHD brains need different systems of support and recognition.

❌ _“If you just tried harder”_  
✅ Effort isn’t the issue—shame and executive function friction are.

❌ _“It’s a lack of discipline”_  
✅ ADHD is a biological difference in regulation, not willpower.

---

## Relational Challenges and Strengths

**Challenges:**

- Missed appointments, forgetting important details
- Hyperfocus on hobbies while neglecting chores
- Emotional reactivity under stress

**Strengths:**

- Passion, creativity, humor, big-picture thinking
- Loyal, attentive, and emotionally present in bursts
- Great in crisis or novel situations

---

## Strategies, Prompts, and Practices

- “What supports would make this easier, not harder?”
- “Where is the shame living in this pattern?”
- Use visual timers, body-doubling, and non-linear planning tools
- Relationship scripts: “My brain dropped that thread—I care and want to stay connected.”

---

## Related Frameworks and Further Reading

- **Polyvagal Theory**
- **Internal Family Systems (IFS)**
- **RSD and Emotional Regulation Models**
- **Executive Function Coaching**
- _Driven to Distraction_ by Hallowell & Ratey
