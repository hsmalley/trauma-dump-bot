<!-- @format -->

# 🧠 Autism Spectrum Disorder (ASD)

## Definition and Core Themes

Autism is a neurodevelopmental identity marked by distinct sensory, communication, and relational processing. It is not a disorder to be “fixed” but a valid way of being. Autism includes diverse manifestations across culture, gender, and ability.

Key truths:

- Autistic people often experience the world intensely and literally
- Social and sensory norms are often not built for autistic needs
- Masking is a survival response, not deception
- Routines, stimming, and special interests are forms of regulation and joy

---

## Traits and Lived Experience

- May prefer deep one-on-one connection over group interaction
- Literal or concrete communication style
- Sensory sensitivities or seeking behaviors
- Strong sense of justice, clarity, and emotional honesty

---

## Nervous System and Parts Work Lens

- **Nervous System**: Autistic burnout is often a cumulative shutdown state from masking, overstimulation, and invalidation
- **Parts**:
  - **Protector**: “If I act normal, maybe they’ll accept me.”
  - **Inner Sensor**: Tunes into details others overlook
  - **Exile**: Carries grief of being misunderstood or shamed

---

## Attachment and Relational Patterns

- May form deep bonds with few people; relationships are often structured or ritualized
- Ruptures may occur around sensory overwhelm or mismatched expectations
- High honesty and loyalty, but may miss neurotypical indirect cues

---

## Misunderstandings and Reframes

❌ _“Autistic people lack empathy”_  
✅ Many autistic people experience _hyper-empathy_ but struggle with social decoding.

❌ _“It’s a childhood disorder”_  
✅ Autism is lifelong—and often missed in adults, especially women and marginalized folks.

❌ _“They’re being rude or robotic”_  
✅ Directness is not a lack of care—it’s a form of respect in autistic culture.

---

## Relational Challenges and Strengths

**Challenges:**

- Misreading or missing implicit social norms
- Sensory needs may conflict with social settings
- Risk of burnout from masking or people-pleasing

**Strengths:**

- Fierce integrity and authentic relating
- Deep presence and interest when attuned
- Capable of building rich, structured, affirming relationships

---

## Strategies, Prompts, and Practices

- “What are my sensory needs right now?”
- “Where am I masking—and is it costing me too much?”
- Use direct scripts: “I’d like to clarify. Was that a joke or a concern?”
- Build relationship rituals: shared calendars, decompression time, parallel play

---

## Related Frameworks and Further Reading

- **Neurodiversity Paradigm**
- **Masking and Burnout Studies**
- **Polyvagal Theory**
- _Unmasking Autism_ by Devon Price
- _Neurotribes_ by Steve Silberman
