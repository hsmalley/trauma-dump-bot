---
title: "Cuckolding"
aliases: ["Cuckqueaning", "Hotwifing", "Cuckoldry", "Cuck"]
tags:
  [
    "frameworks",
    "kink",
    "sexuality",
    "ENM",
    "dynamics",
    "power",
    "emotion",
    "consent",
  ]
---

<!-- @format -->

# 🎭 Cuckolding

**Cuckolding** is a **kink and relational dynamic** where one partner becomes sexually or emotionally aroused by **their partner engaging with other people**—often with **elements of submission, voyeurism, humiliation, compersion**, or emotional intensity. The non-cuckolding partner is sometimes referred to as a **"hotwife"**, **"bull"**, or simply **"partner"**, depending on roles and preferences.

It can be practiced as **part of ENM**, as a **scene-based kink**, or as a **long-term dynamic**. While sometimes rooted in taboo or humiliation, many cuckolding dynamics center on **trust, surrender, arousal, and psychological depth**.

---

## 🧠 Core Elements (Variable Across Dynamics)

### 1. **Consensual Non-Monogamy**

- Involves explicit agreements and disclosures about one partner engaging others.
- Sometimes overlaps with open relationships, swinging, or polyamory.

### 2. **Arousal Through Displacement**

- Erotic charge often comes from jealousy, denial, helplessness, or excitement.
- Not inherently pathological—often highly negotiated and mutually affirming.

### 3. **Power & Psychological Play**

- Can include submission, humiliation, ownership, feminization, or emotional teasing.
- Also compatible with **loving, compersive, and care-centered** versions.

---

## 🔄 Variants and Expressions

| Type                   | Description                                                                    |
| ---------------------- | ------------------------------------------------------------------------------ |
| **Cuckolding (masc)**  | Partner aroused by his wife/partner having sex with others.                    |
| **Cuckqueaning (fem)** | Woman aroused by her male/masc partner having sex with others.                 |
| **Hotwifing**          | Often less humiliation-focused; centered on female partner's pleasure/freedom. |
| **Stag/Vixen**         | Empowered voyeur dynamic without degradation themes.                           |

---

## 🛠 Practice Considerations

- **Scene Design**: Who’s involved, how much is disclosed, what are the psychological limits?
- **Aftercare**: Emotional grounding, reassurance, and re-connection are crucial.
- **Jealousy & Compersion**: Explored consciously—both as kink fuel and emotional terrain.
- **Power Negotiation**: Clarity about humiliation vs playfulness vs resentment is essential.

---

## ⚠️ Ethical & Relational Complexity

- **Shame**: Social stigma can conflate cuckolding with emasculation or dysfunction.
- **Uneven Consent**: Needs to be ongoing, enthusiastic, and revisited—especially when emotional intensity rises.
- **Misuse**: Should not be used to “punish” or bypass relational agreements.

---

## 💬 Reflection Prompts

- What turns me on about this? Is it control, surrender, risk, taboo, power?
- How do I differentiate between playful humiliation and emotional harm?
- What fears or insecurities does this touch—and how do I want to navigate them?
- What does “being chosen” feel like in this dynamic?

---

## 🔗 Related Frameworks

- [[BSDM]] — overview of bsdm concepts and relevance to relationships
- [[Consent Culture]] — collaborative check-ins around needs, pacing, and support
- [[Containment Models]] — where emotional energy needs boundaries or holding
- [[Ethical Non-Monogamy (ENM)]] — shared commitment to openness
- [[Internal Family Systems (IFS)]] — exploring parts involved (insecure, excited, voyeur, self-critical)

## 📚 Further Reading

- Dan Savage – writings and podcast discussions on cuckolding
- Venus Connections – resources on cuckold/cuckquean dynamics
- Multiamory Podcast – kink and non-monogamy episodes
- Dr. Justin Lehmiller – research on cuckolding and fantasy norms
